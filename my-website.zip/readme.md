<!-- in last i wil make a signal rader effect in html and csss -->

<!-- Tomorror i will do about and skill section  -->



<!-- my navbar fade-in wen i will update tge site  -->

<!-- https://www.vivekpanchal.tech/#contact? (inspired by) -->







Portfolio Pure CSS Scroll Snapping Tutorial - https://youtu.be/pNPkVQD7vlM?si=DlfvkJnST5tCUayK 


<!-- last - we will make  a carausel for this -->




<!-- 1- Tomorrow- i will make 5 boxes and make tilt hover effect  -->
<!--  -->
 <!-- a https://codepen.io/felixdorner/pen/oWwpbN -->

<!-- 2- footbar license and privacy polices in details  -->


<!-- 3- also i will learn how to make carausel  -->

<!-- https://youtu.be/nS_Ht0lT-uQ?si=oYomAiqoeZKPBoWG -->


<!-- 

                        <div class="card-item swiper-slide ">
                           <img class="user-image" src="https://blog.ipleaders.in/wp-content/uploads/2019/11/foodmitho-800x533.jpg">
                           <h1 class="project-name">Project-Name</h1>
                           <button class="messaage-button">Click-me</button>
                                

                         </div> --># Protfolio
